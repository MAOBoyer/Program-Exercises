
public class StatusCheck { 
	String status;
	float temperature;
	double mass;
	void checkTemp() {
		if (temperature <= 0 ) {
			status = "Frozen";
		}
		if (temperature > 0 && temperature < 100) {
			status = "Liquid";
		}
		if (temperature >= 100) {
			status = "Gas";
		}
	}
	void showAtt() {
		System.out.println("Status: " + status);
		System.out.println("Mass: " + mass + " grams");
		System.out.println("Temperature: " + temperature + " degrees Celsius");
	}
}