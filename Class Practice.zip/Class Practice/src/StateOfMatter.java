import java.util.*;
public class StateOfMatter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		String query;
		StatusCheck WaterState = new StatusCheck();
		WaterState.status = "Frozen";
		WaterState.mass = 0;
		WaterState.temperature = 0;
		
		WaterState.showAtt();	
		
		System.out.println("Is there a change in status?");
		query = in.toString();
			if (query == "yes") {
				System.out.println("Please state the new mass: ");
				WaterState.mass = in.nextDouble();
				System.out.println("Please input the new temperature: ");
				WaterState.temperature = in.nextFloat();
				WaterState.showAtt();
		}
			if (query == "no") {
				WaterState.showAtt();
		}
	}

}
